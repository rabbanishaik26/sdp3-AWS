package com.klef.demo;

import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

public interface Payrepo extends CrudRepository<PayPojo,String> {
	List<PayPojo>findByName(String name);

}
