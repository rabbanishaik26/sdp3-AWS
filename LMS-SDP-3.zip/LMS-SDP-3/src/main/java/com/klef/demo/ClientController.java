package com.klef.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class ClientController {
	@Autowired
	AdminRepository user;
	@Autowired
	UserRepository ur;
	@RequestMapping(value="/login")
	  public ModelAndView display1()
	  {
		ModelAndView mv = new ModelAndView();
	    mv.setViewName("login");
	    return mv;
	  }
	@RequestMapping(value="/courses")
	  public ModelAndView display2()
	  {
		ModelAndView mv = new ModelAndView();
	    mv.setViewName("courses");
	    return mv;
	  }
	@RequestMapping(value="/logincheck")
    public String logincheck(AdminPOJO u)
    {
		System.out.println(u.username);
      List<AdminPOJO> u2=user.findByUsername(u.username);
      for(AdminPOJO i : u2)
      {
        System.out.println(i.password);
        System.out.println(u.password);
        if(i.password.equals(u.password))
        {
          return "success";
        }
      }
      return "login";
    }
	@PostMapping(value="/registeruser")
	public String registeruser(UserPojo u)
	{
		ur.save(u);
		return "login";
	}
	@RequestMapping(value="/userlogin")
    public ModelAndView userlogin(UserPojo u)
    {
		ModelAndView mv=new ModelAndView("courses");
		UserPojo user=ur.findByCidAndPassword(u.cid, u.password);
		if(user!=null)
		{
			mv.addObject("user",user);
			return mv;
		}
		ModelAndView mv2=new ModelAndView("login");
		mv2.addObject("message","Invalid Login");
      return mv2;
    }
@Autowired
Payrepo rep;
@PostMapping(value="/payment")
	public ModelAndView display1(@ModelAttribute("pay")PayPojo u) {
		rep.save(u);
		ModelAndView mv = new ModelAndView();
		mv.setViewName("success");
		return mv;
	}
@RequestMapping(value="/success")
public ModelAndView userlogin()
{
	ModelAndView mv=new ModelAndView("success");
	
  return mv;
}
}

