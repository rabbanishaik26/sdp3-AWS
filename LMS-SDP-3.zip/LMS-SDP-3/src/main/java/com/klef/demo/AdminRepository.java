package com.klef.demo;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

public interface AdminRepository extends CrudRepository<AdminPOJO,String>{

	List<AdminPOJO>findByUsername(String username);
}
