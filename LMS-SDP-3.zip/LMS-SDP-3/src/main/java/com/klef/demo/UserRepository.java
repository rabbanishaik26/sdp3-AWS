package com.klef.demo;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

public interface UserRepository extends CrudRepository<UserPojo,Integer>
{
	List<UserPojo> findByCid(int cid);
	UserPojo findByCidAndPassword(int cid,String password);
}
