package com.klef.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LmsSdp3Application {

	public static void main(String[] args) {
		SpringApplication.run(LmsSdp3Application.class, args);
	}

}
